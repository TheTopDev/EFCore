﻿using EFCore.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EFCore
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                List<Customer> customers = new List<Customer>();

                using (var ctx = new NorthwindContext())
                {
                    var citiesInOrder = from cust in ctx.Customers
                                        orderby cust.City
                                        select cust;

                    customers = citiesInOrder.ToList();
                }

                Console.WriteLine("Here is a list of cities that our customers reside in: \n");

                foreach (var cust in customers)
                {
                    Console.WriteLine(cust.City + ", ");
                }

                Console.WriteLine("\n \n" + "Enter the name of a city: \n");
                string city = Console.ReadLine();

                using (var ctx = new NorthwindContext())
                {
                    var companiesInCity = from cust in ctx.Customers
                                          where cust.City == city
                                          select cust;

                    customers = companiesInCity.ToList();
                }

                int numOfBusinesses = customers.Count;

                Console.WriteLine($"There are {numOfBusinesses} customers in {city}: ");

                foreach (var cust in customers)
                {
                    Console.WriteLine(cust.CompanyName);
                }
            }
            catch (Exception) 
            {
                Console.WriteLine("Please ensure you have the proper Northwind Database installed on your SSMS, you can download the databade through this link https://github.com/microsoft/sql-server-samples/tree/master/samples/databases/northwind-pubs");
            }
        }
    }
}
